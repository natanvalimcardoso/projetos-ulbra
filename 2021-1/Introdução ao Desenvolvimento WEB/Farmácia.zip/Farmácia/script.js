function calcular (){
    removeAll()

    peso   = parseFloat (document.querySelector(".peso").value);
    altura = parseFloat(document.querySelector(".altura").value);
    
    const resultado  = peso / (altura*altura);
    let img = document.createElement("IMG");
    

    if(resultado < 18.5)
        img.src = "./img2/abaixo.png";
        document.getElementById('imagem').appendChild(img);

    if(resultado > 18.5 && resultado < 24.9)
        img.src = "./img2/normal.png";
        document.getElementById('imagem').appendChild(img);

    if(resultado > 25 &&  resultado < 29.9)
        img.src = "./img2/sobre.png";
        document.getElementById('imagem').appendChild(img);

    if(resultado > 30 &&  resultado < 34.9)
        img.src = "./img2/ob1.png";
        document.getElementById('imagem').appendChild(img);

    if(resultado > 35 &&  resultado < 39.9)
        img.src = "./img2/ob2.png";
        document.getElementById('imagem').appendChild(img);
    if(resultado > 40)
    img.src = "./img2/ob3.png";
    document.getElementById('imagem').appendChild(img);;

    result.innerHTML = mensagem 
    }

////////////////////////////////////////////////////////


    function removeAll(){
        const div = document.getElementById("imagem");
        for (child of div.children){
            child.remove();}
        }

////////////////////////////////////////////////////////

function calculadora (){

    remedio   = parseFloat(document.querySelector("#remedio").value);
    quantidade = parseFloat(document.querySelector("#quantidade").value);
    


    if(remedio == 1){
        remedio = 50.00;
    }
    else if(remedio == 2){
        remedio = 25.00;
    }
    else if(remedio == 3){
        remedio = 15.00;
    }
    else{
        remedio = 0
    }

    let soma = (remedio * quantidade);

    const resposta=document.querySelector("#resposta")
    resposta.innerHTML = soma
    

}

